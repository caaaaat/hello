<?php
class RedisCmdModel extends Model
{

}